/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentaccommodationsystem;

/**
 *
 * @author singhp30
 */
public class Property {
    private String id;
    private String type;
    private String tenantsCount;
    private String rent;
    private String description;
    public void viewProperties(int id){}
    public void approveProperties(Property property){}
    public void reviewProperty(Property property){}

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the tenantsCount
     */
    public String getTenantsCount() {
        return tenantsCount;
    }

    /**
     * @param tenantsCount the tenantsCount to set
     */
    public void setTenantsCount(String tenantsCount) {
        this.tenantsCount = tenantsCount;
    }

    /**
     * @return the rent
     */
    public String getRent() {
        return rent;
    }

    /**
     * @param rent the rent to set
     */
    public void setRent(String rent) {
        this.rent = rent;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }
}
