
public class ListEmptyException extends Exception {

}
