
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;



/**
 * This class use to generate huffman code using a custom priority  queue.
 * @author Shweta
 *
 */
public class Huffman {
	//array containing characters
	char charArray[] = new char[256];
	//array containing characters frequency
	int freq[] = new int[256];
	//variable to iterate array using index
	int index = 0;
	//String variable to get file data
	String s = "";
	//String variable to add file data
	String text;
	//Counter to count characters
	int counter = 0;
	//variable to iterate array
	int i = 0;
	//Custom Class to create node and for tree
	NodeData temp_main;
	
	String[] compress = new String[256];
	
	//Custom Priority Class 
	PriorityFinder P = new PriorityFinder();

	/**
	 * Generates an count and put character and frequency in arrays
	 */
	public void count(String s) {
		text = s;
		for (int i = 0; i < s.length(); i++) {
			int count = 0;
			char ch = s.charAt(i);
			for (int k = 0; k < index; k++) {
				if (charArray[k] != ch)
					count++;
			}
			 // element not present
			if (count == index)
			{

				charArray[index] = ch;
				freq[index] = 1;
				index++;
			} 
			 // element present
			else
			{
				int j;
				for (j = 0; j < index; j++) {
					if (charArray[j] == ch)
						break;
				}
				freq[j]++;

			}

		}

	}

	
	/**
	 * iterate array and show character and their frequency
	 */
	public void display() {
		for (int i = 0; i < index; i++) {
			System.out.println(charArray[i] + "-" + freq[i]);
		}
	}

	/**
	 * iterate array and insert character,frequency to priority queue
	 */
	public void insert() {

		//Loop to iterate array using index
		for (int i = 0; i < index; i++) {
			P.insert((int) charArray[i], freq[i]);
		}
		//Display array elements
		P.display();
	}

	/**
	 * iterate array and delete elements from array
	 */
	public void pop() {
		int totalComparisons=0,totalTimesParentChange=0,totalFindOpr=0,totalAddOpr=0,totalRemOpr=0;
		//variable to add tree elements and find out root element
		int sum = 0;
		
		//A temp variable use to iterate tree using next node address 
		NodeData temp2 = null;
		
		//A temp variable create tree node
		NodeData temp = new NodeData();
		while (P.size > 1) {
			sum = 0;
			temp = new NodeData();
			// pop first two and add and again
			// insert
			for (int i = 0; i < 2; i++) 
										
			{
				temp2 = null;
				try {
					temp2 = P.removeMin();
					sum = sum + temp2.getkey();
					if (i == 0){
						totalComparisons++;
						temp.left = temp2;
					}
					else if (i == 1){
						totalComparisons++;
						temp.right = temp2;
					}
				} catch (ListEmptyException e) {
					e.printStackTrace();
				}

			}
			//insert element to custom priority queue
			P.insert(123, sum, temp);

		}
		System.out.println("Tree root is : " + sum);
		temp_main = temp;
		buildPath(temp, ""); // works !!
		print();
	}

	/**
	 * Path finder function for tree
	 */
	void buildPath(NodeData n, String path) {
		if (n.left != null)
			buildPath(n.left, path + "0");
		if (n.right != null)
			buildPath(n.right, path + "1");
		if (n.left == null && n.right == null) {
			// System.out.println((char)n.data+""+path);
			compress[i] = path;
			charArray[i] = (char) n.data;
			i++;// a child node
			// process the path given to this node
		}
	}

	/**
	 * function to print tree and encode value
	 */
	public void print() {
		AVL bst = new AVL();
		for (int i = 0; i < index; i++){
			//System.out.println(compress[i] + " " + charArray[i]);
			// new code for each
			bst.insert((int) charArray[i], compress[i]);
		}
		String s = "";
		StringBuffer str = new StringBuffer();

		for (int i = 0; i < text.length(); i++) {
			int x = text.charAt(i);
			str.append(bst.search(x));

		}
		s = str.toString();
		int l = s.length() % 8;
		if (l != 0) {
			l = 8 - l;
			String s2 = "";
			switch (l) {
			case 0:
				s2 = "000";
				break;
			case 1:
				s2 = "001";
				break;
			case 2:
				s2 = "010";
				break;
			case 3:
				s2 = "011";
				break;
			case 4:
				s2 = "100";
				break;
			case 5:
				s2 = "101";
				break;
			case 6:
				s2 = "110";
				break;
			case 7:
				s2 = "111";
				break;

			}

			s = s2 + s;
		} else {
			s = "000" + s;
		}
	}

	
	public static void main(String args[]) {
		//
		long start = System.nanoTime();
		Huffman H = new Huffman();
		BufferedReader br = null;
		if(args.length < 1){
			System.out.println("Please enter the file as a command line argument");
			return;
		}
		String fileName = args[0];
		String everything = "";
		try {
			br = new BufferedReader(new FileReader(fileName));
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = br.readLine();
			}
			everything = sb.toString();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		long end = System.nanoTime() - start;
		H.count(everything);
		H.display();
		H.insert();
		H.pop();

		long start2 = System.nanoTime();
		long end2 = System.nanoTime() - start2;
		System.out.println("Time taken is " + end2 + " nano seconds");

	}

}
