
public class PriorityFinder {
	
	/**
     * The number of elements in the priority queue.
     */
	 public int size;
	 
	 // Tree nodes head,tail
     private NodeData header,tail;
     int value,key;
     /**
      * Creates a {@code PriorityQueue} and  tree head,tail
      */
     PriorityFinder(){
         header =new NodeData();
         tail=new NodeData();
         header.setnext(tail);
         tail.setprev(header);
         size=0;
       }
     
     /**
      * @param initialCapacity the initial capacity for this priority queue
      * @throws IllegalArgumentException if {@code initialCapacity} is less
      *         than 1
      */
     
       public int getsize(){
           return(size);
       }
       public boolean isEmpty(){
           if(size==0)
               return true;
           else
               return false;
       }
       /**
        * get min value from queue
        */
       public int min()throws ListEmptyException{
           if(size==0)
               throw new ListEmptyException();
           NodeData q=header.getnext().getnext();int min_key=header.getnext().getkey();int min_value=header.getnext().getvalue();
           while(q.getnext()!=null){
               if(q.getkey()<min_key){
                   min_value=q.getvalue();
               }
               q=q.getnext();
           }
           return(min_key);
       }
       /**
        * remove min value from queue
        */
       public NodeData removeMin()throws ListEmptyException{
            if(size==0)
               throw new ListEmptyException();
            NodeData q=header.getnext();
            int min_key=header.getnext().getkey();
            int min_value=header.getnext().getvalue();
            NodeData temp=q;
            while(q.getnext()!=null){
                if(q.getkey()<min_key){
                   min_value=q.getvalue();
                   min_key=q.getkey();
                   temp=q;
               }
               q=q.getnext();
           }
           
           temp.getprev().setnext(temp.getnext());
           temp.getnext().setprev(temp.getprev());
           size--;
            
           return(temp);
           
       }
       /**
        * Inserts the specified element into this priority queue.
        *
        */
       public void insert(int v,int k,NodeData temp){
           NodeData p=tail.getprev();
           //temp=new NodeData(p,v,k,tail);
           temp.data=v;
           temp.key=k;
           temp.next=tail;
           temp.prev=p;
           p.setnext(temp);
           tail.setprev(temp);
           size++;
       }
       
       /**
        * Inserts the specified element into this priority queue.
        *
        */
       public void insert(int v,int k){
           NodeData p=tail.getprev();
           NodeData q=new NodeData(p,v,k,tail);
           p.setnext(q);
           tail.setprev(q);
           size++;
       }
       
       /**
        * Display queue values
        *
        */
       public void display(){
           NodeData q=header.getnext();
           while(q.getnext()!=null){
               System.out.println(q.getvalue()+"\t"+q.getkey());
               q=q.getnext();
           }
           System.out.println();
       }

}

//Class to create tree node
class NodeData
{
	//for priority queue
	NodeData next;
	NodeData prev;
	//for generating tree
	NodeData left;
	NodeData right;
	int data;
	int key;

	NodeData()
	{
		prev=next=null;
		left=right=null;
		data=key=0;
	}
	NodeData(NodeData p,int val,int k,NodeData n)
	{
		prev=p;
		data=val;
		key=k;
		next=n;
		
	}

	void setData(int v)
	{
		data = v;
	}

	void setnext(NodeData n)
	{
		next = n;
	}

	int getvalue()
	{
		return data;
	}
	int getkey()
	{
		return key;
	}

	NodeData getnext()
	{
		return next;
	}

	void setprev(NodeData n)
	{
	prev = n;
	}

	NodeData getprev()
	{
		return prev;
	}

}
