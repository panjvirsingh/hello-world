package studentaccommodationsystem;

import java.sql.DriverManager;
import java.sql.Connection;
import java.io.*;
import java.util.*;

public class DBConnection {
    public Connection getConnection() {
        Connection connection = null;
        Properties prop = new Properties();
        try {
            prop.load(new FileInputStream("config.properties"));
            String userName = prop.getProperty("dbusername");
            String password = prop.getProperty("dbpassword");
            String url = prop.getProperty("dburl");
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(url, userName, password);
            if (connection != null) {
                System.out.println("You made it, take control your database now!");
            } else {
                System.out.println("Failed to make connection!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return connection;
    }
}
